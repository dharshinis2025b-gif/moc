// Imported from attack_signatures_library.xlsx
export type Signature = { name: string; pattern: string; category: string; description: string };
export const LIBRARY: Signature[] = [
 {
  "name": "SQL Injection",
  "pattern": "or 1=1",
  "category": "SQL Injection",
  "description": "Classic boolean tautology bypass"
 },
 {
  "name": "SQL Injection (UNION)",
  "pattern": "union select",
  "category": "SQL Injection",
  "description": "UNION-based data extraction"
 },
 {
  "name": "SQL Injection (Quote Bypass)",
  "pattern": "' or '1'='1",
  "category": "SQL Injection",
  "description": "Quote-based always-true condition"
 },
 {
  "name": "SQL Injection (Comment)",
  "pattern": "--",
  "category": "SQL Injection",
  "description": "SQL line comment used to truncate query"
 },
 {
  "name": "SQL Injection (Comment Alt)",
  "pattern": "#",
  "category": "SQL Injection",
  "description": "MySQL-style comment truncation"
 },
 {
  "name": "SQL Injection (Stacked Query)",
  "pattern": ";drop table",
  "category": "SQL Injection",
  "description": "Stacked query dropping a table"
 },
 {
  "name": "SQL Injection (Time-based)",
  "pattern": "sleep\\(",
  "category": "SQL Injection",
  "description": "Time-delay blind SQLi via SLEEP()"
 },
 {
  "name": "SQL Injection (Time-based Alt)",
  "pattern": "waitfor delay",
  "category": "SQL Injection",
  "description": "MSSQL time-delay blind SQLi"
 },
 {
  "name": "SQL Injection (Error-based)",
  "pattern": "extractvalue\\(",
  "category": "SQL Injection",
  "description": "MySQL error-based extraction"
 },
 {
  "name": "SQL Injection (Benchmark)",
  "pattern": "benchmark\\(",
  "category": "SQL Injection",
  "description": "MySQL BENCHMARK() time-based SQLi"
 },
 {
  "name": "SQL Injection (Information Schema)",
  "pattern": "information_schema",
  "category": "SQL Injection",
  "description": "Schema enumeration"
 },
 {
  "name": "SQL Injection (Hex Encoding)",
  "pattern": "0x[0-9a-f]+",
  "category": "SQL Injection",
  "description": "Hex-encoded payload bypass (approx.)"
 },
 {
  "name": "XSS (Script Tag)",
  "pattern": "<script",
  "category": "XSS",
  "description": "Classic inline script injection"
 },
 {
  "name": "XSS (Event Handler)",
  "pattern": "(onerror|onload|onclick)=",
  "category": "XSS",
  "description": "Attribute-based event handler XSS"
 },
 {
  "name": "XSS (IMG Tag)",
  "pattern": "<img",
  "category": "XSS",
  "description": "Image tag used to smuggle event handlers"
 },
 {
  "name": "XSS (SVG Tag)",
  "pattern": "<svg",
  "category": "XSS",
  "description": "SVG tag used to smuggle onload payloads"
 },
 {
  "name": "XSS (JS URI)",
  "pattern": "javascript:",
  "category": "XSS",
  "description": "javascript: URI scheme execution"
 },
 {
  "name": "XSS (Iframe)",
  "pattern": "<iframe",
  "category": "XSS",
  "description": "Iframe injection for content/clickjacking"
 },
 {
  "name": "XSS (Data URI)",
  "pattern": "data:text/html",
  "category": "XSS",
  "description": "Data URI used to deliver HTML/script"
 },
 {
  "name": "XSS (Expression)",
  "pattern": "expression\\(",
  "category": "XSS",
  "description": "Legacy CSS expression() JS execution"
 },
 {
  "name": "XSS (Alert Probe)",
  "pattern": "alert\\(",
  "category": "XSS",
  "description": "Common PoC/test payload marker"
 },
 {
  "name": "Path Traversal",
  "pattern": "\\.\\./",
  "category": "Path Traversal",
  "description": "Directory traversal sequence"
 },
 {
  "name": "Path Traversal (Encoded)",
  "pattern": "%2e%2e%2f",
  "category": "Path Traversal",
  "description": "URL-encoded traversal sequence"
 },
 {
  "name": "Sensitive File Access (Passwd)",
  "pattern": "etc/passwd",
  "category": "Path Traversal",
  "description": "Unix credentials file access"
 },
 {
  "name": "Sensitive File Access (Shadow)",
  "pattern": "etc/shadow",
  "category": "Path Traversal",
  "description": "Unix password hash file access"
 },
 {
  "name": "Sensitive File Access (Win.ini)",
  "pattern": "win\\.ini",
  "category": "Path Traversal",
  "description": "Windows config file access"
 },
 {
  "name": "Local File Inclusion",
  "pattern": "php://filter",
  "category": "LFI",
  "description": "PHP wrapper used to read source files"
 },
 {
  "name": "Command Injection",
  "pattern": "(;|\\||&&) *(cat|ls|whoami|id)",
  "category": "Command Injection",
  "description": "Chained shell command execution"
 },
 {
  "name": "Command Injection (Backtick)",
  "pattern": "`.*`",
  "category": "Command Injection",
  "description": "Backtick command substitution"
 },
 {
  "name": "Command Injection (Subshell)",
  "pattern": "\\$\\(.*\\)",
  "category": "Command Injection",
  "description": "Subshell command substitution"
 },
 {
  "name": "Shellshock",
  "pattern": "\\(\\) *\\{",
  "category": "Command Injection",
  "description": "Bash function definition exploit pattern"
 },
 {
  "name": "Remote File Inclusion",
  "pattern": "(http|ftp|file)://",
  "category": "RFI",
  "description": "External resource inclusion"
 },
 {
  "name": "Log4Shell (JNDI)",
  "pattern": "\\$\\{jndi:",
  "category": "RCE",
  "description": "JNDI lookup injection (CVE-2021-44228)"
 },
 {
  "name": "PHP Code Injection",
  "pattern": "<\\?php",
  "category": "RCE",
  "description": "Inline PHP tag injection"
 },
 {
  "name": "Deserialization Probe",
  "pattern": "O:[0-9]+:\"",
  "category": "RCE",
  "description": "PHP serialized object injection marker"
 },
 {
  "name": "XXE Injection",
  "pattern": "<!entity",
  "category": "XXE",
  "description": "XML external entity declaration"
 },
 {
  "name": "XXE (DOCTYPE)",
  "pattern": "<!doctype",
  "category": "XXE",
  "description": "DOCTYPE declaration preceding entity abuse"
 },
 {
  "name": "SSRF (Cloud Metadata)",
  "pattern": "169\\.254\\.169\\.254",
  "category": "SSRF",
  "description": "Cloud instance metadata endpoint probe"
 },
 {
  "name": "SSRF (Localhost)",
  "pattern": "(localhost|127\\.0\\.0\\.1)",
  "category": "SSRF",
  "description": "Internal loopback address targeting"
 },
 {
  "name": "NoSQL Injection",
  "pattern": "\\$where",
  "category": "NoSQL Injection",
  "description": "MongoDB $where operator abuse"
 },
 {
  "name": "NoSQL Injection (Ne)",
  "pattern": "\\$ne",
  "category": "NoSQL Injection",
  "description": "MongoDB $ne operator auth bypass"
 },
 {
  "name": "LDAP Injection",
  "pattern": "\\*\\)\\(",
  "category": "LDAP Injection",
  "description": "LDAP filter manipulation"
 },
 {
  "name": "CRLF Injection",
  "pattern": "%0d%0a",
  "category": "CRLF Injection",
  "description": "HTTP response splitting via encoded CRLF"
 },
 {
  "name": "Header Injection",
  "pattern": "\\r\\n",
  "category": "CRLF Injection",
  "description": "Raw CRLF used for header smuggling"
 },
 {
  "name": "Open Redirect",
  "pattern": "(https?:)?//evil",
  "category": "Open Redirect",
  "description": "Redirect parameter pointing off-site (example domain)"
 },
 {
  "name": "Null Byte Injection",
  "pattern": "%00",
  "category": "Null Byte Injection",
  "description": "Null byte used to truncate file checks"
 },
 {
  "name": "SSTI (Jinja2)",
  "pattern": "\\{\\{.*\\}\\}",
  "category": "SSTI",
  "description": "Server-side template injection marker"
 },
 {
  "name": "SSTI (Freemarker)",
  "pattern": "\\$\\{.*\\}",
  "category": "SSTI",
  "description": "Template expression injection marker"
 }
];
