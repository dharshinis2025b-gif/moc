// @ts-nocheck -- dense index math; covered by src/test/automata.test.ts
// Attributed MDFA pipeline: Shunting-Yard -> Thompson e-NFA -> Subset DFA -> Attributed minimization
export type Rule = { id: number; name: string; pattern: string };
export const OTHER = "\u00b7"; // any char not in alphabet
const CONCAT = "\u2218";
const DOT = "\u0000ANY";

type Tok = { t: "lit" | "op" | "("| ")"; v: string };

const ESC: Record<string, string> = { n: "\n", r: "\r", t: "\t" };
function tokenize(p: string): Tok[] {
  const out: Tok[] = [];
  for (let i = 0; i < p.length; i++) {
    const c = p[i];
    if (c === "\\" && i + 1 < p.length) { const e = p[++i]; out.push({ t: "lit", v: ESC[e] ?? e.toLowerCase() }); }
    else if (c === "[") {
      const set = new Set<string>(); i++;
      while (i < p.length && p[i] !== "]") {
        let a = p[i]; if (a === "\\" && i + 1 < p.length) a = p[++i];
        if (p[i + 1] === "-" && p[i + 2] && p[i + 2] !== "]") {
          const b = p[i + 2]; for (let k = a.charCodeAt(0); k <= b.charCodeAt(0); k++) set.add(String.fromCharCode(k).toLowerCase()); i += 3;
        } else { set.add(a.toLowerCase()); i++; }
      }
      if (p[i] !== "]") throw new Error("Unbalanced [");
      const chars = [...set]; if (!chars.length) throw new Error("Empty [ ]");
      out.push({ t: "(", v: "(" });
      chars.forEach((ch, j) => { if (j) out.push({ t: "op", v: "|" }); out.push({ t: "lit", v: ch }); });
      out.push({ t: ")", v: ")" });
    }
    else if ("|*+?".includes(c)) out.push({ t: "op", v: c });
    else if (c === "(" || c === ")") out.push({ t: c, v: c });
    else if (c === ".") out.push({ t: "lit", v: DOT });
    else out.push({ t: "lit", v: c.toLowerCase() });
  }
  // insert explicit concatenation
  const r: Tok[] = [];
  out.forEach((tk, i) => {
    if (i > 0) {
      const a = out[i - 1];
      const leftOk = a.t === "lit" || a.t === ")" || (a.t === "op" && a.v !== "|");
      const rightOk = tk.t === "lit" || tk.t === "(";
      if (leftOk && rightOk) r.push({ t: "op", v: CONCAT });
    }
    r.push(tk);
  });
  return r;
}

const prec: Record<string, number> = { "|": 1, [CONCAT]: 2, "*": 3, "+": 3, "?": 3 };

export function toPostfix(p: string): Tok[] {
  const out: Tok[] = [], st: Tok[] = [];
  for (const tk of tokenize(p)) {
    if (tk.t === "lit") out.push(tk);
    else if (tk.t === "(") st.push(tk);
    else if (tk.t === ")") {
      while (st.length && st[st.length - 1].t !== "(") out.push(st.pop()!);
      if (!st.length) throw new Error("Unbalanced )");
      st.pop();
    } else {
      while (st.length && st[st.length - 1].t === "op" && prec[st[st.length - 1].v] >= prec[tk.v]) out.push(st.pop()!);
      st.push(tk);
    }
  }
  while (st.length) { const x = st.pop()!; if (x.t === "(") throw new Error("Unbalanced ("); out.push(x); }
  return out;
}
export const postfixString = (toks: Tok[]) => toks.map((t) => (t.v === CONCAT ? "\u00b7" : t.v === DOT ? "." : t.v)).join("");

export type NFA = { n: number; start: number; trans: { from: number; sym: string | null; to: number }[]; accept: Map<number, number> };

export function thompson(rules: Rule[]): NFA {
  let n = 0;
  const trans: NFA["trans"] = [];
  const accept = new Map<number, number>();
  const add = (from: number, sym: string | null, to: number) => trans.push({ from, sym, to });
  const start = n++;
  // Σ* self-loop: scan for attack anywhere in stream
  add(start, "ANY", start);
  for (const r of rules) {
    const st: { s: number; e: number }[] = [];
    for (const tk of toPostfix(r.pattern)) {
      if (tk.t === "lit") { const s = n++, e = n++; add(s, tk.v === DOT ? "ANY" : tk.v, e); st.push({ s, e }); continue; }
      if (tk.v === CONCAT) { const b = st.pop()!, a = st.pop()!; if (!a || !b) throw new Error("Bad pattern"); add(a.e, null, b.s); st.push({ s: a.s, e: b.e }); }
      else if (tk.v === "|") { const b = st.pop()!, a = st.pop()!; if (!a || !b) throw new Error("Bad pattern"); const s = n++, e = n++; add(s, null, a.s); add(s, null, b.s); add(a.e, null, e); add(b.e, null, e); st.push({ s, e }); }
      else { const a = st.pop(); if (!a) throw new Error("Bad pattern"); const s = n++, e = n++; add(s, null, a.s); add(a.e, null, e);
        if (tk.v !== "+") add(s, null, e); if (tk.v !== "?") add(a.e, null, a.s); st.push({ s, e }); }
    }
    if (st.length !== 1) throw new Error(`Bad pattern in rule "${r.name}"`);
    add(start, null, st[0].s);
    accept.set(st[0].e, (accept.get(st[0].e) ?? 0) | (1 << r.id));
  }
  return { n, start, trans, accept };
}

export type DFA = { n: number; start: number; alphabet: string[]; delta: number[][]; mask: number[] };

export function alphabetOf(rules: Rule[]) {
  const s = new Set<string>();
  rules.forEach((r) => toPostfix(r.pattern).forEach((t) => t.t === "lit" && t.v !== DOT && s.add(t.v)));
  return [...[...s].sort(), OTHER];
}

export function subset(nfa: NFA, alphabet: string[]): DFA {
  const eps = new Map<number, number[]>(), mv = new Map<number, { sym: string; to: number }[]>();
  for (const t of nfa.trans) {
    if (t.sym === null) (eps.get(t.from) ?? eps.set(t.from, []).get(t.from)!).push(t.to);
    else (mv.get(t.from) ?? mv.set(t.from, []).get(t.from)!).push({ sym: t.sym, to: t.to });
  }
  const closure = (set: number[]) => { const seen = new Set(set), st = [...set];
    while (st.length) for (const x of eps.get(st.pop()!) ?? []) if (!seen.has(x)) { seen.add(x); st.push(x); }
    return [...seen].sort((a, b) => a - b); };
  const key = (s: number[]) => s.join(",");
  const states: number[][] = [closure([nfa.start])], idx = new Map([[key(states[0]), 0]]);
  const delta: number[][] = [];
  for (let i = 0; i < states.length; i++) {
    delta[i] = alphabet.map((a) => {
      const nx: number[] = [];
      for (const s of states[i]) for (const m of mv.get(s) ?? []) if (m.sym === a || m.sym === "ANY") nx.push(m.to);
      const c = closure(nx), k = key(c);
      if (!idx.has(k)) { idx.set(k, states.length); states.push(c); }
      return idx.get(k)!;
    });
  }
  const mask = states.map((s) => s.reduce((m, x) => m | (nfa.accept.get(x) ?? 0), 0));
  return { n: states.length, start: 0, alphabet, delta, mask };
}

/** Attributed minimization: initial partition splits accepting states by rule bitmask. */
export function minimize(d: DFA, attributed = true): DFA & { rounds: number } {
  let block = d.mask.map((m) => (attributed ? m : m ? 1 : 0));
  let count = new Set(block).size, rounds = 0;
  while (true) {
    rounds++;
    const sig = new Map<string, number>();
    const nb = block.map((b, s) => { const k = b + "|" + d.delta[s].map((t) => block[t]).join(",");
      if (!sig.has(k)) sig.set(k, sig.size); return sig.get(k)!; });
    block = nb;
    if (sig.size === count) break;
    count = sig.size;
  }
  // renumber with start = 0 in BFS order
  const order = new Map<number, number>([[block[d.start], 0]]), q = [d.start], rep: number[] = [d.start];
  while (q.length) { const s = q.shift()!; for (const t of d.delta[s]) if (!order.has(block[t])) { order.set(block[t], order.size); rep.push(t); q.push(t); } }
  return { n: rep.length, start: 0, alphabet: d.alphabet, rounds,
    delta: rep.map((s) => d.delta[s].map((t) => order.get(block[t])!)),
    mask: rep.map((s) => (attributed ? d.mask[s] : d.mask[s] ? -1 : 0)) };
}

export type Step = { i: number; ch: string; from: number; to: number };
export function scan(m: DFA, text: string) {
  const col = new Map(m.alphabet.map((a, i) => [a, i]));
  const other = m.alphabet.length - 1, steps: Step[] = [];
  let s = m.start;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i].toLowerCase(), to = m.delta[s][col.get(ch) ?? other];
    steps.push({ i, ch: text[i], from: s, to }); s = to;
    if (m.mask[s]) return { steps, blocked: true, index: i, mask: m.mask[s] };
  }
  return { steps, blocked: false, index: -1, mask: 0 };
}

export function compile(rules: Rule[]) {
  const alphabet = alphabetOf(rules), nfa = thompson(rules), dfa = subset(nfa, alphabet);
  return { alphabet, nfa, dfa, mdfa: minimize(dfa, true), classic: minimize(dfa, false),
    postfix: rules.map((r) => postfixString(toPostfix(r.pattern))) };
}
