import { describe, it, expect } from "vitest";
import { compile, scan } from "@/lib/automata";

const rules = [
  { id: 0, name: "SQLi", pattern: "or 1=1" },
  { id: 1, name: "XSS", pattern: "<script" },
  { id: 2, name: "Traversal", pattern: "\\.\\./" },
];

describe("attributed MDFA", () => {
  const c = compile(rules);
  it("blocks and attributes the right rule", () => {
    const r = scan(c.mdfa, "id=5 OR 1=1");
    expect(r.blocked).toBe(true);
    expect(r.mask).toBe(1);
    expect(scan(c.mdfa, "a<script>").mask).toBe(2);
    expect(scan(c.mdfa, "/../etc").mask).toBe(4);
  });
  it("passes safe traffic", () => expect(scan(c.mdfa, "hello world").blocked).toBe(false));
  it("minimized never larger than DFA", () => expect(c.mdfa.n).toBeLessThanOrEqual(c.dfa.n));
});

describe("signature library", async () => {
  const { LIBRARY } = await import("@/lib/signatures");
  it("every library pattern compiles", () => { for (const s of LIBRARY) expect(() => compile([{ id: 0, name: s.name, pattern: s.pattern }])).not.toThrow(); });
  it("char classes work", () => expect(scan(compile([{ id: 0, name: "hex", pattern: "0x[0-9a-f]+" }]).mdfa, "id=0x1f").blocked).toBe(true));
  it("escaped dot is literal", () => expect(scan(compile([{ id: 0, name: "t", pattern: "\\.\\./" }]).mdfa, "ab/").blocked).toBe(false));
});
